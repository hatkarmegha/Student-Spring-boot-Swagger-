package com.example.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Student;

public interface StudentDao extends JpaRepository<Student, Integer> 
{
	@Query("select s from Student s where sbranch=?1")
	List<Student> getByBranch(String sbranch);
	
	@Query("select count(s) from Student s where sbranch=?1")
	int countSameBranch(String sbranch);
}
