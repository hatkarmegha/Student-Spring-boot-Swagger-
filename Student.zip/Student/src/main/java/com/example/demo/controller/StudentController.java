package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.dao.StudentDao;
import com.example.demo.model.Student;

@RestController
public class StudentController 
{
	@Autowired
	StudentDao dao;
	
	@RequestMapping("/")
	 public ModelAndView home()
	 {
		System.out.println("Hi...");
		ModelAndView mv=new ModelAndView("home.jsp");
		 return mv;
	 }
	
	@RequestMapping("/add")
	public ModelAndView addStudent(Student stud)
	{
		dao.save(stud);
		ModelAndView mv=new ModelAndView("home.jsp");
		return mv;
	}
	
//-----------------------------------------------------------------------------	
	
	
	//------display all students----
	@GetMapping("/students")
	public List<Student> allStudents()
	{
		return dao.findAll();
	}
	
	//---------add student---------
	@PostMapping(path="/student",consumes = {"application/json"})
	public Student addStud(@RequestBody Student stud)
	{
		dao.save(stud);
		return stud;
	}
	
	//-------getting one student info----
	@GetMapping("/student/{sid}")
	public Optional<Student> getstudent(@PathVariable("sid") int sid)
	{

		return dao.findById(sid);
	}
	
	//--------Update student--------
	@PutMapping(path="/student",consumes = {"application/json"})
	public Student updateOrSaveStudent(@RequestBody Student stud)
	{
		dao.save(stud);
		return stud;
	}
	
	//------Delete student----------
	@DeleteMapping("/student/{sid}")
	public String deletestudent(@PathVariable int sid)
	{
		//Optional<Student> s=dao.findById(sid);
		dao.deleteById(sid);
		return "deleted";
	}
	
	//-------No. of students--------
	@GetMapping("/totalstudent")
	public long totalStudent()
	{	
		return dao.count();
	}
	
	//--------Delete all record-------
	@DeleteMapping("/students")
	public String deleteAllStudent()
	{
		dao.deleteAll();
		return "All record deleted";
	}
	
	//-----------display student of same branch---
	@GetMapping("/students/{sbranch}")
	public List<Student> getStudentByBranch(@PathVariable String sbranch)
	{
		return dao.getByBranch(sbranch);
	}
	
	//------no.of students in same branch---
	@GetMapping("/cntbybranch/{sbranch}")
	public int countSameBranch(@PathVariable String sbranch)
	{
		return dao.countSameBranch(sbranch);
	}
}
